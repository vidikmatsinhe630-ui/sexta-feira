package com.vidik.sexta;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Avisos: notificação com som e voz. */
final class Say {
  private Say() { }
  static final String CH_ALERT = "pagamentos", CH_RUN = "sexta";
  private static TextToSpeech tts;
  private static boolean ready, starting;
  private static final List<String> pending = new ArrayList<>();
  private static int nid = 100;

  static void channels(Context c) {
    NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    nm.createNotificationChannel(new NotificationChannel(CH_RUN, "Sexta-feira a vigiar", NotificationManager.IMPORTANCE_LOW));
    nm.createNotificationChannel(new NotificationChannel(CH_ALERT, "Pagamentos", NotificationManager.IMPORTANCE_HIGH));
  }

  static void event(Context c, String tipo, String txt) {
    if (tipo.equals("recusado")) return;
    if (Store.notif(c)) notify(c, title(tipo), txt);
    if (Store.voice(c)) speak(c, txt);
  }

  static String title(String tipo) {
    switch (tipo) {
      case "confirmado": return "Pagamento confirmado";
      case "menos": return "Pagou a menos";
      case "entrada": return "Dinheiro sem pedido";
      case "pedido": return "Pedido novo";
      case "expirou": return "Pedido sem pagamento";
      case "saida": return "Saída de dinheiro";
      case "erro": return "Não consegui ativar";
      default: return "Sexta-feira";
    }
  }

  static void notify(Context c, String title, String txt) {
    try {
      channels(c);
      PendingIntent pi = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
      Notification n = new Notification.Builder(c, CH_ALERT).setContentTitle(title).setContentText(txt).setStyle(new Notification.BigTextStyle().bigText(txt))
        .setSmallIcon(android.R.drawable.stat_notify_chat).setContentIntent(pi).setAutoCancel(true).build();
      ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(nid++ % 40 + 100, n);
    } catch (Exception e) { }
  }

  /** o que se diz em voz alta: sem IDs e com "meticais" */
  static String spoken(String t) {
    String s = t.replaceAll("\\s*\\(?\\bID\\s+PP\\d{6}\\.\\d{4}\\.[A-Za-z0-9]{6}\\)?", "").replaceAll("PP\\d{6}\\.\\d{4}\\.[A-Za-z0-9]{6}", "")
      .replaceAll("(\\d)\\s*MT\\b", "$1 meticais").replace("1 meticais", "1 metical");
    s = s.replaceAll("(\\d{1,2})/(\\d{1,2})/(\\d{4})", "$1 do $2 de $3");
    return s.replaceAll("\\s+", " ").trim();
  }

  /** a resposta da conversa: corta o que estava a dizer e fala já */
  static synchronized void speakNow(Context c, String txt) { stop(); speak(c, txt); }
  static synchronized void stop() { try { if (tts != null && ready) tts.stop(); pending.clear(); } catch (Exception e) { } }

  static synchronized void speak(final Context c0, String txt) {
    final Context c = c0.getApplicationContext();
    String t = spoken(txt);
    if (t.isEmpty()) return;
    if (ready && tts != null) { tts.speak(t, TextToSpeech.QUEUE_ADD, null, "sx" + System.nanoTime()); return; }
    pending.add(t);
    if (starting) return;
    starting = true;
    tts = new TextToSpeech(c, new TextToSpeech.OnInitListener() {
      public void onInit(int status) {
        synchronized (Say.class) {
          starting = false;
          if (status != TextToSpeech.SUCCESS) { pending.clear(); return; }
          int r = tts.setLanguage(new Locale("pt", "MZ"));
          if (r < 0) r = tts.setLanguage(new Locale("pt", "PT"));
          if (r < 0) r = tts.setLanguage(new Locale("pt", "BR"));
          ready = true;
          for (String p : pending) tts.speak(p, TextToSpeech.QUEUE_ADD, null, "sx" + System.nanoTime());
          pending.clear();
        }
      }
    });
  }
}
