package com.vidik.sexta;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;

/** Fala com o servidor: manda os SMS lidos, ouve as novidades e lê a caixa de entrada. */
final class Sync {
  private Sync() { }

  /** manda ao servidor os SMS na fila; para no primeiro erro de rede. Devolve "" ou o motivo. */
  static synchronized String flush(Context c) {
    JSONArray q = Store.queue(c);
    if (q.length() == 0) return "";
    JSONArray rest = new JSONArray(); String err = "";
    for (int i = 0; i < q.length(); i++) {
      JSONObject o;
      try { o = q.getJSONObject(i); } catch (Exception e) { continue; }
      if (!err.isEmpty()) { rest.put(o); continue; }
      try {
        Api.call(c, "POST", "/sexta/sms", new JSONObject().put("txid", o.optString("txid")).put("valor", o.optDouble("valor")).put("de", o.optString("de")).put("dir", o.optString("dir")).put("ts", o.optLong("ts")).toString());
        Store.markSeen(c, o.optString("id"));
      } catch (Api.Fail f) {
        if (f.code == 400) { Store.markSeen(c, o.optString("id")); continue; }   // o servidor diz que a mensagem não serve: não insistir
        err = f.getMessage(); rest.put(o);
      } catch (Exception e) { err = "Sem rede."; rest.put(o); }
    }
    Store.setQueue(c, rest);
    if (!err.isEmpty()) Store.err(c, err); else Store.ok(c);
    return err;
  }

  /** ouve as novidades do servidor e anuncia-as. Devolve "" ou o motivo do erro. */
  static String poll(Context c) {
    try {
      boolean first = Store.after(c) == 0 && !Store.started(c);
      String s = Api.call(c, "GET", "/sexta/estado?after=" + Store.after(c), null);
      JSONObject j = new JSONObject(s);
      Store.ok(c);
      JSONArray ev = j.optJSONArray("eventos");
      long last = Store.after(c);
      boolean news = false;
      if (first) { Store.setAfter(c, j.optLong("ultimo", 0)); Store.setStarted(c); news = true; }
      else if (ev != null) {
        for (int i = 0; i < ev.length(); i++) {
          JSONObject e = ev.getJSONObject(i);
          last = Math.max(last, e.optLong("id"));
          Say.event(c, e.optString("tipo"), e.optString("txt"));
          news = true;
        }
        if (last != Store.after(c)) Store.setAfter(c, last);
      }
      JSONObject r = j.optJSONObject("resumo");
      int w = r == null ? 0 : r.optInt("espera");
      String hoje = r == null ? "" : fmt(r.optDouble("hoje"));
      Store.setLine(c, (w > 0 ? w + (w == 1 ? " pedido à espera" : " pedidos à espera") : "Nenhum pedido à espera") + " · hoje " + hoje + " MT");
      if (news) Hub.notifyUi();
      return "";
    } catch (Api.Fail f) { Store.err(c, f.getMessage()); return f.getMessage(); }
    catch (Exception e) { Store.err(c, "Sem rede."); return "Sem rede."; }
  }

  static String fmt(double v) { return Math.abs(v - Math.rint(v)) < 0.005 ? String.valueOf((long) Math.rint(v)) : String.format(java.util.Locale.US, "%.2f", v).replace('.', ','); }

  /** lê os SMS das últimas horas e põe os de dinheiro na fila. Devolve quantos encontrou. */
  static int scan(Context c, int horas) {
    int n = 0;
    Cursor cur = null;
    try {
      long since = System.currentTimeMillis() - horas * 3600_000L;
      cur = c.getContentResolver().query(Uri.parse("content://sms/inbox"), new String[]{"body", "date"}, "date>?", new String[]{String.valueOf(since)}, "date DESC");
      if (cur == null) return 0;
      int ib = cur.getColumnIndex("body"), id = cur.getColumnIndex("date");
      while (cur.moveToNext() && n < 300) {
        SmsParse.Sms s = SmsParse.parse(cur.getString(ib));
        if (s == null) continue;
        String key = (s.in ? "i:" : "o:") + s.tx;
        if (Store.seen(c, key)) continue;
        Store.push(c, s, cur.getLong(id)); n++;
      }
    } catch (Exception e) { }
    finally { if (cur != null) cur.close(); }
    return n;
  }
}
