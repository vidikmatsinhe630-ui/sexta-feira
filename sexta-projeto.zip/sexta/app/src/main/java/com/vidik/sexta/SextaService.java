package com.vidik.sexta;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.PowerManager;

/** Fica sempre a vigiar: manda os SMS ao servidor e ouve as novidades a cada poucos segundos. */
public class SextaService extends Service {
  private volatile boolean run;
  private PowerManager.WakeLock wl;
  private Thread th;

  private Notification note() {
    PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
    String err = Store.err(this);
    return new Notification.Builder(this, Say.CH_RUN).setContentTitle(err.isEmpty() ? "Sexta-feira a vigiar" : "Sexta-feira com problema").setContentText(err.isEmpty() ? Store.line(this) : err)
      .setSmallIcon(android.R.drawable.stat_notify_sync).setContentIntent(pi).setOngoing(true).build();
  }

  public int onStartCommand(Intent i, int f, int id) {
    Say.channels(this);
    try { startForeground(7, note()); } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
    if (wl == null) { wl = ((PowerManager) getSystemService(Context.POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sexta:svc"); wl.setReferenceCounted(false); }
    if (!wl.isHeld()) wl.acquire(12 * 3600 * 1000L);
    if (!run) {
      run = true;
      final Context c = getApplicationContext();
      th = new Thread(new Runnable() { public void run() { loop(c); } }, "sexta");
      th.setDaemon(true); th.start();
    }
    return START_STICKY;
  }

  private void loop(Context c) {
    long lastScan = 0, lastNote = 0;
    boolean firstRun = true;
    while (run) {
      long now = System.currentTimeMillis();
      String err = "";
      if (!Store.key(c).isEmpty()) {
        if (firstRun || now - lastScan > 120_000L) { Sync.scan(c, firstRun ? 72 : 6); lastScan = now; firstRun = false; }
        err = Sync.flush(c);
        if (err.isEmpty()) err = Sync.poll(c);
        if (wl != null && !wl.isHeld()) wl.acquire(12 * 3600 * 1000L);
        if (now - lastNote > 15_000L || !err.isEmpty()) {
          try { ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(7, note()); } catch (Exception e) { }
          lastNote = now;
        }
      }
      try { Thread.sleep(err.isEmpty() ? 4000 : 15000); } catch (InterruptedException e) { return; }
    }
  }

  public void onDestroy() { run = false; if (th != null) th.interrupt(); if (wl != null && wl.isHeld()) wl.release(); super.onDestroy(); }
  public IBinder onBind(Intent i) { return null; }

  static void start(Context c) { try { c.startForegroundService(new Intent(c, SextaService.class)); } catch (Exception e) { } }
}
