package android.os;
public class Handler { public Handler(){} public Handler(Looper l){} public boolean postDelayed(Runnable r,long d){return true;} public boolean post(Runnable r){return true;} }
