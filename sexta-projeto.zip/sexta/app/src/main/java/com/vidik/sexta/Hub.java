package com.vidik.sexta;

/** Avisa a janela aberta de que há novidades e acorda o serviço quando há trabalho (SMS novo, rede de volta). */
final class Hub {
  private Hub() { }
  static volatile Runnable ui;
  static void notifyUi() { Runnable r = ui; if (r != null) { try { r.run(); } catch (Exception e) { } } }

  private static final Object LOCK = new Object();
  private static boolean kicked;
  /** acorda o fio de trabalho já */
  static void kick() { synchronized (LOCK) { kicked = true; LOCK.notifyAll(); } }
  /** dorme até ms, ou até alguém chamar kick(). Devolve false se foi interrompido (serviço a parar). */
  static boolean nap(long ms) {
    synchronized (LOCK) {
      try { if (!kicked) LOCK.wait(ms); } catch (InterruptedException e) { return false; }
      kicked = false; return true;
    }
  }
}
