package com.vidik.sexta;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lê um SMS do e-Mola: dinheiro recebido ("Recebeu") ou enviado ("Transferiste"), o valor e o ID da transação (PP...). */
final class SmsParse {
  private SmsParse() { }

  static final class Sms {
    String tx = ""; double valor; boolean in; String party = "";
  }

  private static final Pattern TX = Pattern.compile("(?i)\\bPP\\d{6}\\.\\d{4}\\.[A-Z0-9]{6}\\b");
  private static final Pattern AMT = Pattern.compile("([0-9][0-9., ]*[0-9]|[0-9])\\s*(?:MT|MZN|MTN)", Pattern.CASE_INSENSITIVE);

  static String norm(String s) {
    String d = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD);
    return d.replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT);
  }

  /** "1.00" → 1, "1,000.50" → 1000.5, "1.234,50" → 1234.5, "1.000" → 1000, "150,00" → 150 */
  static double money(String raw) {
    String s = raw.replace(" ", "");
    int dot = s.lastIndexOf('.'), com = s.lastIndexOf(',');
    int sep = Math.max(dot, com);
    if (sep < 0) return Double.parseDouble(s);
    String frac = s.substring(sep + 1);
    boolean decimal;
    if (dot >= 0 && com >= 0) decimal = true;
    else {
      char c = s.charAt(sep);
      decimal = frac.length() <= 2 || (s.indexOf(c) != sep);
      if (s.indexOf(c) != sep) decimal = false;          // separador repetido: é de milhares
      else if (frac.length() == 3) decimal = false;       // 1.000 → mil
    }
    if (!decimal) return Double.parseDouble(s.replace(".", "").replace(",", ""));
    String whole = s.substring(0, sep).replace(".", "").replace(",", "");
    return Double.parseDouble((whole.isEmpty() ? "0" : whole) + "." + frac);
  }

  /** null se não for uma mensagem de dinheiro com ID de transação */
  static Sms parse(String text) {
    if (text == null || text.length() > 900) return null;
    String t = text.replaceAll("\\s+", " ").trim();
    Matcher m = TX.matcher(t);
    if (!m.find()) return null;
    Sms r = new Sms(); r.tx = m.group().toUpperCase(Locale.ROOT);
    String low = norm(t);
    int in = firstOf(low, "recebeu", "recebeste", "recebido"), out = firstOf(low, "transferiste", "enviaste", "levantaste", "pagaste");
    if (in < 0 && out < 0) return null;
    r.in = in >= 0 && (out < 0 || in < out);
    int from = r.in ? in : out;
    Matcher a = AMT.matcher(t);
    double v = -1;
    while (a.find()) { if (a.start() >= from - 1 || v < 0) { try { v = money(a.group(1)); } catch (Exception e) { v = -1; } if (a.start() >= from - 1 && v > 0) break; } }
    if (!(v > 0)) return null;
    r.valor = v;
    Matcher p = Pattern.compile(r.in ? "(?i)\\bde\\s+(?:258)?(8[2-7]\\d{7})(?!\\d)" : "(?i)\\bpara\\s+(?:258)?(8[2-7]\\d{7})(?!\\d)").matcher(t);
    if (p.find()) r.party = p.group(1);
    else { Matcher n = Pattern.compile("(?<!\\d)(?:258)?(8[2-7]\\d{7})(?!\\d)").matcher(t); if (n.find()) r.party = n.group(1); }
    return r;
  }

  private static int firstOf(String s, String... w) {
    int best = -1;
    for (String x : w) { Matcher m = Pattern.compile("\\b" + x + "\\b").matcher(s); if (m.find() && (best < 0 || m.start() < best)) best = m.start(); }
    return best;
  }
}
