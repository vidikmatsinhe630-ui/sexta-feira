package android.content; public abstract class ContentResolver { public abstract android.database.Cursor query(android.net.Uri u,String[] p,String s,String[] a,String o); }
