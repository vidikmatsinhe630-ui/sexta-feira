package com.vidik.sexta;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  WebView w;
  static final String VER = "1.3.0";
  static final int REQ_MIC = 77, REQ_VID = 78;

  protected void onCreate(Bundle b) {
    super.onCreate(b);
    w = new WebView(this); w.setBackgroundColor(0xFF060A1B);
    WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setTextZoom(100);
    w.setWebViewClient(new WebViewClient());
    w.addJavascriptInterface(new Bridge(), "Android");
    setContentView(w);
    w.loadUrl("file:///android_asset/ui.html");
    ask();
    if (!Store.key(this).isEmpty()) SextaService.start(this);
  }
  protected void onResume() { super.onResume(); Hub.ui = new Runnable() { public void run() { push(); } }; push(); }
  protected void onPause() { super.onPause(); Hub.ui = null; }

  void push() { runOnUiThread(new Runnable() { public void run() { if (w != null) w.evaluateJavascript("window.onSx&&onSx()", null); } }); }

  void ask() {
    java.util.ArrayList<String> p = new java.util.ArrayList<>();
    if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.RECEIVE_SMS);
    if (checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.READ_SMS);
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.POST_NOTIFICATIONS);
    if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), 1);
  }
  /** o senhor fala: abre o reconhecimento de voz do telemóvel e devolve o texto à conversa */
  void listen() {
    try {
      Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
      i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
      i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT");
      i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com a Sexta-feira");
      i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
      Say.stop();
      startActivityForResult(i, REQ_MIC);
    } catch (Exception e) {
      Toast.makeText(this, "Este telemóvel não tem reconhecimento de voz.", Toast.LENGTH_LONG).show();
      sendMic("");
    }
  }
  protected void onActivityResult(int req, int res, Intent data) {
    super.onActivityResult(req, res, data);
    if (req == REQ_VID) { if (res == RESULT_OK && data != null && data.getData() != null) Vids.upload(this, data.getData()); return; }
    if (req != REQ_MIC) return;
    String t = "";
    try {
      java.util.ArrayList<String> r = res == RESULT_OK && data != null ? data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) : null;
      if (r != null && !r.isEmpty()) t = r.get(0);
    } catch (Exception e) { }
    sendMic(t);
  }
  void sendMic(String t) { final String js = "window.onMic&&onMic(" + JSONObject.quote(t == null ? "" : t) + ")"; runOnUiThread(new Runnable() { public void run() { if (w != null) w.evaluateJavascript(js, null); } }); }

  public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r, p, g); push(); }

  String cfg() throws Exception {
    boolean sms = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
    boolean nt = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    boolean bat = ((PowerManager) getSystemService(Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());
    return new JSONObject().put("ok", true).put("base", Store.base(this)).put("keySet", !Store.key(this).isEmpty()).put("voice", Store.voice(this)).put("chatVoice", Store.chatVoice(this)).put("notif", Store.notif(this))
      .put("okAt", Store.okAt(this)).put("err", Store.err(this)).put("ver", VER).put("sms", sms).put("nt", nt).put("bat", bat).put("line", Store.line(this))
      .put("fila", Store.queue(this).length()).toString();
  }

  static String fail(String m) { try { return new JSONObject().put("ok", false).put("error", m).toString(); } catch (Exception e) { return "{\"ok\":false}"; } }

  class Bridge {
    /** a interface chama, a resposta volta por window.__cb(id, texto) */
    @JavascriptInterface public void sx(final String op, final String arg, final String id) {
      new Thread(new Runnable() { public void run() {
        String r;
        try { r = MainActivity.this.run(op, arg == null ? new String[0] : arg.split("\u0001", -1)); }
        catch (Api.Fail f) { r = fail(f.getMessage()); }
        catch (Exception e) { r = fail("Sem rede ou erro: " + e.getMessage()); }
        final String js = "window.__cb&&__cb(" + JSONObject.quote(id) + "," + JSONObject.quote(r) + ")";
        runOnUiThread(new Runnable() { public void run() { if (w != null) w.evaluateJavascript(js, null); } });
      } }).start();
    }
  }

  String ok() { return "{\"ok\":true}"; }

  String run(String op, String[] a) throws Exception {
    switch (op) {
      case "vid.pick": runOnUiThread(new Runnable() { public void run() { try { Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("video/*"); startActivityForResult(i, REQ_VID); } catch (Exception e) { Toast.makeText(MainActivity.this, "Não consegui abrir os vídeos.", Toast.LENGTH_LONG).show(); } } }); return ok();
      case "vid.st": return Vids.status();
      case "vid.list": return Api.call(this, "GET", "/sexta/video/lista", null);
      case "vid.del": return Api.call(this, "POST", "/sexta/video/apagar", new JSONObject().put("id", Long.parseLong(a[0])).toString());
      case "cfg": return cfg();
      case "cfg.save": Store.save(this, a[0].isEmpty() ? null : a[0], a[1].isEmpty() ? "" : a[1], a[2].equals("1"), a[3].equals("1")); SextaService.start(this); return ok();
      case "ping": return Api.call(this, "GET", "/sexta/ping", null);
      case "dados": {
        try { String s = Api.call(this, "GET", "/sexta/dados?dias=120", null); Store.setSnap(this, s); Store.ok(this); return s; }
        catch (Api.Fail f) { Store.err(this, f.getMessage()); throw f; }
      }
      case "snap": { String s = Store.snap(this); return s.isEmpty() ? "{\"ok\":false}" : s; }
      case "confirmar": return Api.call(this, "POST", "/sexta/confirmar", new JSONObject().put("id", Long.parseLong(a[0])).toString());
      case "recusar": return Api.call(this, "POST", "/sexta/recusar", new JSONObject().put("id", Long.parseLong(a[0])).toString());
      case "saida": return Api.call(this, "POST", "/sexta/saida", new JSONObject().put("valor", Double.parseDouble(a[0].replace(',', '.'))).put("txt", a[1]).put("quem", a[2]).toString());
      case "saida.editar": return Api.call(this, "POST", "/sexta/saida/editar", new JSONObject().put("id", Long.parseLong(a[0])).put("txt", a[1]).put("quem", a[2]).toString());
      case "chat": return Api.call(this, "POST", "/sexta/chat", new JSONObject().put("msg", a[0]).toString(), 50000);
      case "chat.hist": return Api.call(this, "GET", "/sexta/chat/hist", null);
      case "chat.limpar": return Api.call(this, "POST", "/sexta/chat/limpar", new JSONObject().put("tudo", a.length > 0 && a[0].equals("1")).toString());
      case "mem": return Api.call(this, "GET", "/sexta/mem", null);
      case "mem.del": return Api.call(this, "POST", "/sexta/mem/del", new JSONObject().put("id", Long.parseLong(a[0])).toString());
      case "fala": Say.speakNow(this, a[0]); return ok();
      case "calar": Say.stop(); return ok();
      case "cfg.cv": Store.setChatVoice(this, a[0].equals("1")); if (!a[0].equals("1")) Say.stop(); return ok();
      case "mic": runOnUiThread(new Runnable() { public void run() { listen(); } }); return ok();
      case "msgs": return Msgs.snapshot(this, 12);
      case "scan": { int n = Sync.scan(this, 72); Sync.flush(this); SextaService.start(this); return new JSONObject().put("ok", true).put("n", n).toString(); }
      case "say": Say.speak(this, "Boa noite, senhor. A Sexta-feira está a ouvir. Recebi 99 MT."); return ok();
      case "ask": runOnUiThread(new Runnable() { public void run() { ask(); } }); return ok();
      case "battery": runOnUiThread(new Runnable() { public void run() { try { startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))); } catch (Exception x) { } } }); return ok();
      case "copy": { final String t = a[0]; runOnUiThread(new Runnable() { public void run() { ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("sexta", t)); Toast.makeText(MainActivity.this, "Copiado", Toast.LENGTH_SHORT).show(); } }); return ok(); }
      default: return fail("operação desconhecida");
    }
  }
}
