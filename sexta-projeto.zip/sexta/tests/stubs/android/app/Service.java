package android.app;
public abstract class Service extends android.content.Context { public static final int START_STICKY=1,START_NOT_STICKY=2; public abstract android.os.IBinder onBind(android.content.Intent i);
 public int onStartCommand(android.content.Intent i,int f,int id){return 0;} public void onDestroy(){} public final void startForeground(int id,Notification n){} public final void stopSelf(){}
 public android.content.Context getApplicationContext(){return null;} public android.content.SharedPreferences getSharedPreferences(String n,int m){return null;} public Object getSystemService(String n){return null;} public int checkSelfPermission(String p){return 0;}
 public android.content.ComponentName startForegroundService(android.content.Intent i){return null;} public String getPackageName(){return null;} public void startActivity(android.content.Intent i){} public android.content.ContentResolver getContentResolver(){return null;} }
