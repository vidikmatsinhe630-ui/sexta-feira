package android.net; public class Uri { public static Uri parse(String s){return null;} public String getLastPathSegment(){return "";} }
