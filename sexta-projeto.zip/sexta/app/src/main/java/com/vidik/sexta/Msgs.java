package com.vidik.sexta;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;

/** Conversas do e-Mola e do M-Pesa na caixa de SMS deste telemóvel (as mensagens, não as notificações). */
final class Msgs {
  private Msgs() { }

  /** que serviço é este remetente: "em", "mp" ou "" */
  static String kind(String addr) {
    if (addr == null) return "";
    String a = addr.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]", "");
    if (a.contains("mpesa")) return "mp";
    if (a.contains("emola")) return "em";
    return "";
  }

  /** SMS acabados de chegar: a caixa de SMS do Android demora segundos a gravá-los, por isso guarda-os aqui para o cartão os mostrar logo */
  private static final java.util.ArrayList<Object[]> FRESH = new java.util.ArrayList<>();
  static synchronized void fresh(String addr, String body, long t) {
    if (kind(addr).isEmpty() || body == null) return;
    FRESH.add(0, new Object[]{addr, body, t}); while (FRESH.size() > 8) FRESH.remove(FRESH.size() - 1);
  }
  private static synchronized java.util.List<Object[]> freshCopy() { return new java.util.ArrayList<>(FRESH); }

  static boolean allowed(Context c) {
    try { return c.checkSelfPermission(android.Manifest.permission.READ_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED; } catch (Throwable t) { return false; }
  }

  /** {"perm":bool,"em":{"n":N,"msgs":[{"t":ms,"b":"texto","in":true,"v":valor,"tx":"ID"}]},"mp":{...}} com as últimas mensagens de cada conversa (mais recentes primeiro) */
  static String snapshot(Context c, int max) throws Exception {
    JSONObject out = new JSONObject().put("perm", allowed(c));
    JSONObject em = new JSONObject().put("n", 0).put("msgs", new JSONArray()), mp = new JSONObject().put("n", 0).put("msgs", new JSONArray());
    if (allowed(c)) {
      Cursor q = null;
      try {
        q = c.getContentResolver().query(Uri.parse("content://sms/inbox"), new String[]{"address", "body", "date"}, null, null, "date DESC");
        int rows = 0;
        while (q != null && q.moveToNext() && ++rows <= 600) {
          String k = kind(q.getString(0)); if (k.isEmpty()) continue;
          JSONObject o = k.equals("em") ? em : mp; o.put("n", o.getInt("n") + 1);
          JSONArray a = o.getJSONArray("msgs"); if (a.length() >= max) continue;
          String body = q.getString(1) == null ? "" : q.getString(1);
          JSONObject m = new JSONObject().put("t", q.getLong(2)).put("b", body.length() > 400 ? body.substring(0, 400) : body);
          SmsParse.Sms s = SmsParse.parse(body);
          if (s != null) m.put("in", s.in).put("v", s.valor).put("tx", s.tx);
          a.put(m);
        }
      } catch (Exception e) { }
      finally { if (q != null) q.close(); }
    }
    // mensagens já recebidas mas ainda não gravadas na caixa: entram à frente, sem repetir as que a caixa já tem
    long now = System.currentTimeMillis();
    for (Object[] f : freshCopy()) {
      String body = (String) f[1]; long t = (Long) f[2]; String k = kind((String) f[0]); if (k.isEmpty() || now - t > 10 * 60000L) continue;
      JSONObject o = k.equals("em") ? em : mp; JSONArray a = o.getJSONArray("msgs"); boolean dup = false;
      for (int i = 0; i < a.length(); i++) { JSONObject x = a.getJSONObject(i); String xb = x.optString("b"); if (Math.abs(x.optLong("t") - t) < 180000L && (body.startsWith(xb) || xb.startsWith(body))) { dup = true; break; } }
      if (dup) continue;
      JSONObject m = new JSONObject().put("t", t).put("b", body.length() > 400 ? body.substring(0, 400) : body);
      SmsParse.Sms sp = SmsParse.parse(body); if (sp != null) m.put("in", sp.in).put("v", sp.valor).put("tx", sp.tx);
      JSONArray n2 = new JSONArray(); n2.put(m); for (int i = 0; i < a.length() && n2.length() < max; i++) n2.put(a.get(i));
      o.put("msgs", n2).put("n", o.getInt("n") + 1);
    }
    return out.put("em", em).put("mp", mp).toString();
  }
}
