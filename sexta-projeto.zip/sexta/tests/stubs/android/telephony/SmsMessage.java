package android.telephony; public class SmsMessage { public String getMessageBody(){return "";} }
