package com.vidik.sexta;

/** Avisa a janela aberta de que há novidades. */
final class Hub {
  private Hub() { }
  static volatile Runnable ui;
  static void notifyUi() { Runnable r = ui; if (r != null) { try { r.run(); } catch (Exception e) { } } }
}
