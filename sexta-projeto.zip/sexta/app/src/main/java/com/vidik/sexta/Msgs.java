package com.vidik.sexta;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;

/** Conversas do e-Mola e do M-Pesa na caixa de SMS deste telemóvel (as mensagens, não as notificações). */
final class Msgs {
  private Msgs() { }

  /** que serviço é este remetente: "em", "mp" ou "" */
  static String kind(String addr) {
    if (addr == null) return "";
    String a = addr.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]", "");
    if (a.contains("mpesa")) return "mp";
    if (a.contains("emola")) return "em";
    return "";
  }

  static boolean allowed(Context c) {
    try { return c.checkSelfPermission(android.Manifest.permission.READ_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED; } catch (Throwable t) { return false; }
  }

  /** {"perm":bool,"em":{"n":N,"msgs":[{"t":ms,"b":"texto","in":true,"v":valor,"tx":"ID"}]},"mp":{...}} com as últimas mensagens de cada conversa (mais recentes primeiro) */
  static String snapshot(Context c, int max) throws Exception {
    JSONObject out = new JSONObject().put("perm", allowed(c));
    JSONObject em = new JSONObject().put("n", 0).put("msgs", new JSONArray()), mp = new JSONObject().put("n", 0).put("msgs", new JSONArray());
    if (allowed(c)) {
      Cursor q = null;
      try {
        q = c.getContentResolver().query(Uri.parse("content://sms/inbox"), new String[]{"address", "body", "date"}, null, null, "date DESC");
        int rows = 0;
        while (q != null && q.moveToNext() && ++rows <= 600) {
          String k = kind(q.getString(0)); if (k.isEmpty()) continue;
          JSONObject o = k.equals("em") ? em : mp; o.put("n", o.getInt("n") + 1);
          JSONArray a = o.getJSONArray("msgs"); if (a.length() >= max) continue;
          String body = q.getString(1) == null ? "" : q.getString(1);
          JSONObject m = new JSONObject().put("t", q.getLong(2)).put("b", body.length() > 400 ? body.substring(0, 400) : body);
          SmsParse.Sms s = SmsParse.parse(body);
          if (s != null) m.put("in", s.in).put("v", s.valor).put("tx", s.tx);
          a.put(m);
        }
      } catch (Exception e) { }
      finally { if (q != null) q.close(); }
    }
    return out.put("em", em).put("mp", mp).toString();
  }
}
