package android.app;
public class Notification { public static class Style {} public static class BigTextStyle extends Style { public BigTextStyle bigText(CharSequence t){return this;} }
 public static class Builder { public Builder(android.content.Context c,String ch){} public Builder setContentTitle(CharSequence t){return this;} public Builder setContentText(CharSequence t){return this;} public Builder setStyle(Style s){return this;}
  public Builder setSmallIcon(int i){return this;} public Builder setContentIntent(PendingIntent p){return this;} public Builder setOngoing(boolean b){return this;} public Builder setAutoCancel(boolean b){return this;} public Notification build(){return null;} } }
