package android; public final class R { public static final class drawable { public static final int stat_notify_chat=1,stat_notify_sync=2; } }
