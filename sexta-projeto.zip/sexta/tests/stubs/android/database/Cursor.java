package android.database; public interface Cursor { boolean moveToNext(); String getString(int i); long getLong(int i); int getColumnIndex(String n); void close(); }
