package com.vidik.sexta;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Cão de guarda: de poucos em poucos minutos acorda e, se o serviço morreu, volta a pô-lo a vigiar. */
public class Watch extends BroadcastReceiver {
  public void onReceive(Context c, Intent i) {
    arm(c);
    if (!Store.key(c).isEmpty() && !SextaService.alive()) SextaService.start(c);
  }

  static void arm(Context c) {
    try {
      AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
      PendingIntent pi = PendingIntent.getBroadcast(c, 77, new Intent(c, Watch.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
      am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 3 * 60_000L, pi);
    } catch (Exception e) { }
  }
}
