#!/bin/sh
# Compila a app contra stubs do Android (confere nomes, tipos e chamadas). O teste a sério é o build do GitHub.
D=$(cd "$(dirname "$0")" && pwd); O=$(mktemp -d)
javac -Xlint:-options -d "$O" $(find "$D/stubs" -name "*.java") $(find "$D/../app/src/main/java" -name "*.java") 2>&1 | grep -v JAVA_TOOL
echo "compilação terminada"
