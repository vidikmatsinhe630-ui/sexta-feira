package android.content;
public abstract class Context { public static final String NOTIFICATION_SERVICE="notification",POWER_SERVICE="power",CLIPBOARD_SERVICE="clipboard",ALARM_SERVICE="alarm",CONNECTIVITY_SERVICE="connectivity";
 public abstract Context getApplicationContext(); public abstract SharedPreferences getSharedPreferences(String n,int m); public abstract Object getSystemService(String n); public abstract int checkSelfPermission(String p);
 public abstract ComponentName startForegroundService(Intent i); public abstract String getPackageName(); public abstract void startActivity(Intent i); public abstract ContentResolver getContentResolver(); }
