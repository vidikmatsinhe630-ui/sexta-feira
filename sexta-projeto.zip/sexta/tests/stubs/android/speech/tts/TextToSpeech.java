package android.speech.tts; public class TextToSpeech { public static final int SUCCESS=0,QUEUE_ADD=1; public interface OnInitListener { void onInit(int status); }
 public TextToSpeech(android.content.Context c,OnInitListener l){} public int setLanguage(java.util.Locale l){return 0;} public int stop(){return 0;} public int speak(CharSequence t,int m,android.os.Bundle p,String id){return 0;} }
