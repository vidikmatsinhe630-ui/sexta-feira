package com.vidik.sexta;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

/** Recebe cada SMS que chega ao telemóvel. Se for dinheiro do e-Mola, vai logo para o servidor. */
public class SmsReceiver extends BroadcastReceiver {
  public void onReceive(final Context c0, Intent i) {
    final Context c = c0.getApplicationContext();
    try {
      SmsMessage[] ms = Telephony.Sms.Intents.getMessagesFromIntent(i);
      if (ms == null || ms.length == 0) return;
      StringBuilder b = new StringBuilder();
      for (SmsMessage m : ms) b.append(m.getMessageBody() == null ? "" : m.getMessageBody());
      SmsParse.Sms s = SmsParse.parse(b.toString());
      Msgs.fresh(ms[0].getOriginatingAddress(), b.toString(), System.currentTimeMillis());
      Hub.notifyUi();
      // a caixa de SMS grava com atraso: avisa a interface mais vezes para o cartão mostrar a mensagem já
      final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
      for (int d : new int[]{1000, 3000, 6000}) h.postDelayed(new Runnable() { public void run() { Hub.notifyUi(); } }, d);
      if (s == null) return;
      Store.push(c, s, System.currentTimeMillis());
      final PendingResult pr = goAsync();
      new Thread(new Runnable() { public void run() { try { Sync.flush(c); } finally { pr.finish(); } } }).start();
      SextaService.start(c);
    } catch (Exception e) { }
  }
}
