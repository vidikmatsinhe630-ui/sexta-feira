package android.app;
public class Activity extends android.content.Context { public void setContentView(android.view.View v){} public final void runOnUiThread(Runnable r){}
 protected void onCreate(android.os.Bundle b){} protected void onResume(){} protected void onPause(){} public final void requestPermissions(String[] p,int c){} public void onRequestPermissionsResult(int r,String[] p,int[] g){}
 public android.content.Context getApplicationContext(){return null;} public android.content.SharedPreferences getSharedPreferences(String n,int m){return null;} public Object getSystemService(String n){return null;} public int checkSelfPermission(String p){return 0;}
 public android.content.ComponentName startForegroundService(android.content.Intent i){return null;} public String getPackageName(){return null;} public void startActivity(android.content.Intent i){} public android.content.ContentResolver getContentResolver(){return null;} }
