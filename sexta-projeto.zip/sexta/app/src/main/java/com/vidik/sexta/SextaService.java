package com.vidik.sexta;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.IBinder;
import android.os.PowerManager;

/** Fica sempre a vigiar. Dois fios: um mantém a ligação aberta com o servidor (responde logo que há novidade) e outro lê e envia os SMS. */
public class SextaService extends Service {
  private static volatile boolean alive;
  private volatile boolean run;
  private PowerManager.WakeLock wl;
  private Thread work, listen;
  private ConnectivityManager cm;
  private ConnectivityManager.NetworkCallback cb;

  static boolean alive() { return alive; }

  private Notification note() {
    PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
    String err = Store.err(this);
    return new Notification.Builder(this, Say.CH_RUN).setContentTitle(err.isEmpty() ? "Sexta-feira a vigiar" : "Sexta-feira a reconectar").setContentText(err.isEmpty() ? Store.line(this) : err)
      .setSmallIcon(android.R.drawable.stat_notify_sync).setContentIntent(pi).setOngoing(true).build();
  }

  public int onStartCommand(Intent i, int f, int id) {
    Say.channels(this);
    try { startForeground(7, note()); } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
    if (wl == null) { wl = ((PowerManager) getSystemService(Context.POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sexta:svc"); wl.setReferenceCounted(false); }
    if (!wl.isHeld()) wl.acquire(12 * 3600 * 1000L);
    Watch.arm(this);
    if (!run) {
      run = true; alive = true;
      final Context c = getApplicationContext();
      work = new Thread(new Runnable() { public void run() { work(c); } }, "sexta-work"); work.setDaemon(true); work.start();
      listen = new Thread(new Runnable() { public void run() { listen(c); } }, "sexta-listen"); listen.setDaemon(true); listen.start();
      try {
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        cb = new ConnectivityManager.NetworkCallback() { public void onAvailable(Network n) { Hub.kick(); } };
        cm.registerDefaultNetworkCallback(cb);
      } catch (Exception e) { cb = null; }
    }
    Hub.kick();
    return START_STICKY;
  }

  /** lê a caixa de SMS, manda os SMS ao servidor e mantém a notificação */
  private void work(Context c) {
    long lastScan = 0, lastNote = 0;
    boolean firstRun = true;
    while (run) {
      long now = System.currentTimeMillis();
      if (!Store.key(c).isEmpty()) {
        try {
          if (firstRun || now - lastScan > 60_000L) { Sync.scan(c, firstRun ? 72 : 6); lastScan = now; firstRun = false; }
          Sync.flush(c);
          if (wl != null && !wl.isHeld()) wl.acquire(12 * 3600 * 1000L);
          if (now - lastNote > 20_000L) { ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(7, note()); lastNote = now; Hub.notifyUi(); }
        } catch (Throwable t) { }
      }
      if (!Hub.nap(Store.queue(c).length() > 0 ? 5000 : 15000)) return;
    }
  }

  /** ligação aberta: pergunta ao servidor "há novidades?" e ele só responde quando há; assim que responde, volta a perguntar */
  private void listen(Context c) {
    long lastPoll = 0; int bad = 0;
    while (run) {
      if (Store.key(c).isEmpty()) { if (!Hub.nap(5000)) return; continue; }
      long now = System.currentTimeMillis();
      try {
        if (lastPoll == 0 || now - lastPoll > 60_000L) {       // ponto de partida e resumo do dia
          String e = Sync.poll(c); lastPoll = System.currentTimeMillis();
          if (!e.isEmpty()) { bad++; if (!Hub.nap(Math.min(15000, 2000L * bad))) return; continue; }
          bad = 0;
        }
        Boolean r = Sync.listen(c);
        if (r == null) { bad++; if (!Hub.nap(Math.min(15000, 2000L * bad))) return; continue; }
        bad = 0;
        if (r) { Sync.poll(c); lastPoll = System.currentTimeMillis(); }
        try { ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(7, note()); } catch (Exception x) { }
      } catch (Throwable t) { if (!Hub.nap(5000)) return; }
    }
  }

  public void onTaskRemoved(Intent root) { Watch.arm(this); super.onTaskRemoved(root); }
  public void onDestroy() {
    run = false; alive = false; Hub.kick();
    if (cm != null && cb != null) { try { cm.unregisterNetworkCallback(cb); } catch (Exception e) { } }
    if (wl != null && wl.isHeld()) wl.release();
    Watch.arm(this);
    super.onDestroy();
  }
  public IBinder onBind(Intent i) { return null; }

  static void start(Context c) { try { c.startForegroundService(new Intent(c, SextaService.class)); } catch (Exception e) { } }
}
