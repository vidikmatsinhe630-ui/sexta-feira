package com.vidik.sexta;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
  public void onReceive(Context c, Intent i) { Watch.arm(c); if (!Store.key(c).isEmpty()) SextaService.start(c); }
}
