package android; public final class Manifest { public static final class permission { public static final String RECEIVE_SMS="a",READ_SMS="b",POST_NOTIFICATIONS="c"; } }
