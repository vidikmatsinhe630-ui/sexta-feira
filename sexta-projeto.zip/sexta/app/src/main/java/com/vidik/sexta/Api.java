package com.vidik.sexta;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

/** Pedidos ao servidor da Aurum, sempre com a chave do dono. */
final class Api {
  private Api() { }

  static final class Fail extends Exception {
    final int code;
    Fail(int code, String m) { super(m); this.code = code; }
  }

  static String call(Context c, String method, String path, String body) throws Exception { return call(c, method, path, body, 25000); }

  static String call(Context c, String method, String path, String body, int readMs) throws Exception {
    if (Store.key(c).isEmpty()) throw new Fail(0, "Falta a chave do dono.");
    HttpURLConnection h = (HttpURLConnection) new URL(Store.base(c) + path).openConnection();
    h.setRequestMethod(method); h.setConnectTimeout(8000); h.setReadTimeout(readMs);
    h.setRequestProperty("x-sexta", Store.key(c)); h.setRequestProperty("Content-Type", "application/json");
    if (body != null) { h.setDoOutput(true); h.getOutputStream().write(body.getBytes("UTF-8")); }
    int code = h.getResponseCode();
    InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
    String s = in == null ? "" : read(in);
    h.disconnect();
    if (code == 200) return s;
    String m = "";
    try { m = new JSONObject(s).optString("error"); } catch (Exception e) { }
    throw new Fail(code, m.isEmpty() ? "Erro " + code : m);
  }

  private static String read(InputStream in) throws Exception {
    ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[4096]; int n;
    while ((n = in.read(b)) > 0) o.write(b, 0, n);
    in.close();
    return o.toString("UTF-8");
  }
}
