package android.telephony; public class SmsMessage { public String getOriginatingAddress(){return "";} public String getMessageBody(){return "";} }
