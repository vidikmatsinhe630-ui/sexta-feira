package com.vidik.sexta;

import android.content.Context;
import android.net.Uri;
import java.io.*;
import org.json.JSONObject;

/** Vídeos do menu da Aurum: a Sexta-feira envia-os em partes para o servidor e a Aurum descarrega e vai alternando. */
final class Vids {
  private Vids() { }
  static final int PART = 600_000; static final long MAX = 24_000_000L;
  static volatile String msg = ""; static volatile boolean busy;

  /** copia o vídeo escolhido e envia; corre em segundo plano */
  static void upload(final Context c, final Uri uri) {
    if (busy) return; busy = true; msg = "A preparar o vídeo...";
    new Thread(new Runnable() { public void run() {
      File tmp = null;
      try {
        tmp = new File(c.getCacheDir(), "vid_up.tmp");
        InputStream in = c.getContentResolver().openInputStream(uri); if (in == null) throw new IOException("Não consegui abrir o vídeo.");
        long size = 0; FileOutputStream o = new FileOutputStream(tmp); byte[] b = new byte[16384]; int n;
        while ((n = in.read(b)) > 0) { o.write(b, 0, n); size += n; if (size > MAX) { in.close(); o.close(); throw new IOException("O vídeo é grande demais (máximo 24 MB). Comprima-o primeiro."); } }
        in.close(); o.close();
        if (size == 0) throw new IOException("O vídeo está vazio.");
        int parts = (int) ((size + PART - 1) / PART);
        String nome = String.valueOf(uri.getLastPathSegment()); if (nome.length() > 60) nome = nome.substring(nome.length() - 60);
        JSONObject r = new JSONObject(Api.call(c, "POST", "/sexta/video/novo", new JSONObject().put("nome", nome).put("n", parts).put("size", size).toString()));
        long id = r.optLong("id");
        FileInputStream f = new FileInputStream(tmp);
        for (int i = 0; i < parts; i++) {
          byte[] buf = new byte[PART]; int got = 0; while (got < PART) { int k = f.read(buf, got, PART - got); if (k <= 0) break; got += k; }
          byte[] real = new byte[got]; System.arraycopy(buf, 0, real, 0, got);
          String d = android.util.Base64.encodeToString(real, android.util.Base64.NO_WRAP);
          msg = "A enviar o vídeo... " + (i + 1) + " de " + parts;
          boolean ok = false; Exception last = null;
          for (int t = 0; t < 4 && !ok; t++) { try { Api.call(c, "POST", "/sexta/video/parte", new JSONObject().put("id", id).put("i", i).put("d", d).toString(), 60000); ok = true; } catch (Exception e) { last = e; try { Thread.sleep(2000); } catch (Exception x) { } } }
          if (!ok) { f.close(); try { Api.call(c, "POST", "/sexta/video/apagar", new JSONObject().put("id", id).toString()); } catch (Exception x) { } throw last == null ? new IOException("Falhou o envio.") : last; }
        }
        f.close(); msg = "Vídeo enviado. A Aurum vai passar a usá-lo no menu.";
      } catch (Exception e) { msg = "Falhou: " + e.getMessage(); }
      finally { if (tmp != null) tmp.delete(); busy = false; Hub.notifyUi(); }
    } }, "vids").start();
  }
  static String status() { return "{\"busy\":" + busy + ",\"msg\":" + JSONObject.quote(msg) + "}"; }
}
