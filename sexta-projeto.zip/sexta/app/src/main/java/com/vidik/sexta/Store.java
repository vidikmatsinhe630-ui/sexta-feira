package com.vidik.sexta;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Definições e filas da app, guardadas no telemóvel. */
final class Store {
  private Store() { }
  static final String BASE = "https://aurum-servidor.vidikmatsinhe630.workers.dev";
  static SharedPreferences sp(Context c) { return c.getApplicationContext().getSharedPreferences("sexta", 0); }

  static String base(Context c) { String b = sp(c).getString("base", ""); return b.isEmpty() ? BASE : b; }
  static String key(Context c) { return sp(c).getString("key", ""); }
  static boolean voice(Context c) { return sp(c).getBoolean("voice", true); }
  static boolean notif(Context c) { return sp(c).getBoolean("notif", true); }
  static long after(Context c) { return sp(c).getLong("after", 0); }
  static void setAfter(Context c, long v) { sp(c).edit().putLong("after", v).apply(); }
  static boolean started(Context c) { return sp(c).getBoolean("started", false); }
  static void setStarted(Context c) { sp(c).edit().putBoolean("started", true).apply(); }

  static void save(Context c, String key, String base, boolean voice, boolean notif) {
    SharedPreferences.Editor e = sp(c).edit();
    if (key != null) e.putString("key", key.trim());
    if (base != null) e.putString("base", base.trim().replaceAll("/+$", ""));
    e.putBoolean("voice", voice).putBoolean("notif", notif).apply();
  }

  // estado da ligação, para a interface mostrar
  static void ok(Context c) { sp(c).edit().putLong("okAt", System.currentTimeMillis()).putString("err", "").apply(); }
  static void err(Context c, String m) { sp(c).edit().putString("err", m == null ? "" : m).apply(); }
  static long okAt(Context c) { return sp(c).getLong("okAt", 0); }
  static String err(Context c) { return sp(c).getString("err", ""); }

  /** fila de SMS ainda por enviar ao servidor */
  static synchronized void push(Context c, SmsParse.Sms s, long ts) {
    try {
      String id = (s.in ? "i:" : "o:") + s.tx;
      if (seen(c, id)) return;
      JSONArray q = queue(c);
      for (int i = 0; i < q.length(); i++) if (id.equals(q.getJSONObject(i).optString("id"))) return;
      q.put(new JSONObject().put("id", id).put("txid", s.tx).put("valor", s.valor).put("de", s.party).put("dir", s.in ? "in" : "out").put("ts", ts));
      sp(c).edit().putString("queue", q.toString()).apply();
    } catch (Exception e) { }
  }
  static synchronized JSONArray queue(Context c) {
    try { return new JSONArray(sp(c).getString("queue", "[]")); } catch (Exception e) { return new JSONArray(); }
  }
  static synchronized void setQueue(Context c, JSONArray q) { sp(c).edit().putString("queue", q.toString()).apply(); }

  /** SMS que o servidor já recebeu (para não os mandar outra vez a cada leitura da caixa de entrada) */
  static synchronized boolean seen(Context c, String id) { return sp(c).getString("seen", "").contains("|" + id + "|"); }
  static synchronized void markSeen(Context c, String id) {
    String s = sp(c).getString("seen", "|");
    if (s.contains("|" + id + "|")) return;
    s = s + id + "|";
    if (s.length() > 12000) s = "|" + s.substring(s.length() - 9000).replaceFirst("^[^|]*\\|", "");
    sp(c).edit().putString("seen", s).apply();
  }

  static String snap(Context c) { return sp(c).getString("snap", ""); }
  static void setSnap(Context c, String s) { sp(c).edit().putString("snap", s).apply(); }
  static String line(Context c) { return sp(c).getString("line", "A vigiar pagamentos"); }
  static void setLine(Context c, String s) { sp(c).edit().putString("line", s).apply(); }
}
