package com.vidik.sexta;

public class SmsParseTest {
  static int ok, bad;
  static void t(boolean c, String m) { if (c) ok++; else { bad++; System.out.println("FALHOU: " + m); } }
  public static void main(String[] a) {
    SmsParse.Sms s = SmsParse.parse("ID Trans: PP261027.1029.H97116. Recebeu 1.00MT de 861988969, o seu saldo e 25.00MT. Conteudo: 555");
    t(s != null && s.in && s.tx.equals("PP261027.1029.H97116") && s.valor == 1.0 && s.party.equals("861988969"), "recebido real");
    s = SmsParse.parse("ID da transacao PP261026.1921.c68165. Transferiste 10.00MT para 878040088 com sucesso.");
    t(s != null && !s.in && s.tx.equals("PP261026.1921.C68165") && s.valor == 10.0 && s.party.equals("878040088"), "enviado real, ID em minúsculas passa a maiúsculas");
    s = SmsParse.parse("ID Trans: PP261101.0812.A12345. Recebeu 1.250,50MT de 841234567. Saldo 3.000,00MT");
    t(s != null && s.in && s.valor == 1250.5, "milhares e decimais: " + (s == null ? "null" : s.valor));
    s = SmsParse.parse("ID Trans: PP261101.0812.A12345. Recebeu 1,250.50MT de 841234567.");
    t(s != null && s.valor == 1250.5, "formato inglês");
    s = SmsParse.parse("ID Trans: PP261101.0812.A12345. Recebeu 1.000MT de 841234567.");
    t(s != null && s.valor == 1000.0, "1.000 é mil");
    s = SmsParse.parse("ID Trans: PP261101.0812.A12345. Recebeu 150,00 MT de 258841234567.");
    t(s != null && s.valor == 150.0 && s.party.equals("841234567"), "150,00 MT com prefixo 258");
    t(SmsParse.parse("Promocao: ganhe megas hoje") == null, "SMS normal ignorado");
    t(SmsParse.parse("Confirmado ABC123XYZ9. Recebeu 150,00MT de 841234567") == null, "M-Pesa não tem PP: ignorado");
    t(SmsParse.parse("ID Trans: PP261101.0812.A12345. O seu codigo e 1234") == null, "sem verbo: ignorado");
    t(SmsParse.parse(null) == null, "nulo");
    s = SmsParse.parse("ID Trans: PP261101.0812.A12345. Recebeste 99MT de 841234567.");
    t(s != null && s.valor == 99.0 && s.in, "recebeste sem decimais");
    System.out.println(ok + " ok, " + bad + " falhas"); if (bad > 0) System.exit(1);
  }
}
