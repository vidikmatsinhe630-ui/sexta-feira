package android.os; public class PowerManager { public static final int PARTIAL_WAKE_LOCK=1; public boolean isIgnoringBatteryOptimizations(String p){return false;} public WakeLock newWakeLock(int l,String t){return null;}
 public static class WakeLock { public void setReferenceCounted(boolean b){} public boolean isHeld(){return false;} public void acquire(long t){} public void release(){} } }
