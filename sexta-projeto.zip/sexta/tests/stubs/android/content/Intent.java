package android.content; public class Intent { public Intent(Context c,Class<?> k){} public Intent(String a,android.net.Uri u){} public Intent(String a){} }
